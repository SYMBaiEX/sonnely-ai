# Sonnely SDK for TypeScript

Run text inference on Sonnely from Node.js 22.12 or newer. Create a funded [Sonnely API key](https://sonnely.com/console/keys) and store it server-side as `SONNELY_API_KEY`.

```ts
import { Sonnely } from "@sonnely/sdk";

const sonnely = new Sonnely({ apiKey: process.env.SONNELY_API_KEY });
const request = {
  model: "z-ai/glm-5.3-flash",
  messages: [{ role: "user" as const, content: "Describe winter in two words." }],
  max_tokens: 128,
  max_cost_microusd: 500,
};
const result = await sonnely.complete(request, { receipt: true });
console.log(result.choices[0]?.message.content, result.usage);
```

Call `models()` for live routes and rates. Use `stream(request, { receipt: true })` for an async iterator that yields text deltas and final usage. The iterator requires the gateway's settlement marker to complete normally. Each completion or stream is billed separately.

[SDK guide](https://docs.sonnely.com/docs/sdks) · [API reference](https://docs.sonnely.com/docs/api) · [Usage](https://sonnely.com/console/usage)

Use `infer(endpoint, body)` for Responses, text or file workloads, and WAV speech output. The result includes `data` and `requestId`. Pass a `FormData` body for PDF, audio, and image uploads. Use `providerModels()` for full catalog discovery and `realtimeConnection()` for the URL and bearer headers accepted by a server-side WebSocket client. See the [SDK guide](https://docs.sonnely.com/docs/sdks#specialized-inference).

Pass `idempotencyKey` to `complete` or `stream` when you need to retry an operation. Use `onResponse` to capture the gateway request ID on a successful response. `SonnelyError` exposes `status`, `requestId`, and `retryAfter`. A duplicate key returns HTTP 409 with the original request ID.

Set `provider: { only: ["near-ai", "phala"], allow_fallbacks: true }` on a completion or stream request to allow ordered private failover. Check the exact model’s `routes[].private_failover` and `routes[].capabilities` with `models()`. The `onResponse` callback exposes `provider` when the gateway names a serving provider. JSON completions include `sonnely_provider`. See the [SDK guide](https://docs.sonnely.com/docs/sdks#private-routing-and-failover).
